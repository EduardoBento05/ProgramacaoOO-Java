package exercicio04;

public class Veiculo {
	
	private int placa;

	public Veiculo(int placa) {
		this.placa = placa;
	}

	public int getPlaca() {
		return placa;
	}
	
	

}
